<?php 
	$config = array(
		"mysql_server" => "localhost",
		"mysql_user" => "root",
		"mysql_password" => "root",
		"mysql_db" => "a3_pokemon"
	);		
?>